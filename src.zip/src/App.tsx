import { useEffect, useLayoutEffect, useRef, useState } from "react";
import "./App.css";
import { SearchHeader } from "./components/SearchHeader";
import { CandidateCard } from "./components/CandidateCard";
import { SearchHero } from "./components/SearchHero";
import { CandidateProfileDialog, type ProfileTab } from "./components/CandidateProfileDialog";
import {
  BANDS,
  rangeFromSelection,
  selectionFromRange,
} from "./features/filters/filterExperience";
import { getCandidateDisplayMatchStatus } from "./features/candidates/candidateWorkflow";
import {
  CONTACT_STATUSES,
  loadContacts,
  saveContacts,
  type ContactRecord,
  type ContactStatus,
} from "./features/contacts/contactTracker";
import {
  hasAnyFilter,
  loadSearch,
  saveSearch,
  type SavedFilters,
} from "./features/search/searchSession";

const API_URL = "http://127.0.0.1:8000/search";
const SPELLING_CHECK_URL = "http://127.0.0.1:8000/search/suggestion";
const FILTER_SEARCH_URL = "http://127.0.0.1:8000/search/refine";
const RESUME_API_URL = "http://127.0.0.1:8000/candidates";

import type {
  BackendCandidate,
  BackendSearchResponse,
  Candidate,
  MatchedSkill,
  CandidateView,
  ContactCandidate,
  Evidence,
  ExperienceTimelineEntry,
  LocationSuggestion,
  MatchedRequirement,
  SearchResponse,
  SelectedLocation,
  SeniorityBand,
} from "./types/candidate";
import {
  getInitials,
  formatMonths,
  normalizeExternalUrl,
  buildMailtoLink,
  getMatchedExperience,
} from "./features/candidates/candidatePresentation";

function normalizeCandidate(
  raw: BackendCandidate
): Candidate | null {
  const nestedCandidate =
    raw.candidate ?? {};

  const id =
    raw.id ??
    nestedCandidate.id;

  const name =
    raw.name ??
    nestedCandidate.name;

  if (
    id === undefined ||
    !name
  ) {
    return null;
  }

  const email =
    raw.email ??
    nestedCandidate.email ??
    null;

  let score =
    raw.match_score ??
    raw.score;

  if (
    score === undefined ||
    score === null ||
    Number.isNaN(Number(score))
  ) {
    score = 0;
  }

  /*
   * The backend can return matched_skills in more than
   * one shape. Structured results currently return skill
   * names as strings, while other result shapes may return
   * objects. Normalize both forms here so the renderer never
   * tries to read skill.skill from a string.
   */
  const rawMatchedSkills =
    Array.isArray(raw.matched_skills)
      ? raw.matched_skills
      : [];

  const matchedSkills: MatchedSkill[] =
    rawMatchedSkills.flatMap((item): MatchedSkill[] => {
        if (typeof item === "string") {
          const isPrimarySkill =
            raw.skill &&
            item.toLowerCase() ===
              raw.skill.toLowerCase();

          return [{
            skill: item,
            last_used: isPrimarySkill
              ? raw.last_used_date ??
                raw.last_used ??
                null
              : null,
            total_months: isPrimarySkill
              ? raw.total_months ??
                undefined
              : undefined,
          }];
        }

        if (
          !item ||
          typeof item !== "object" ||
          !item.skill
        ) {
          return [];
        }

        return [{
          skill: item.skill,
          last_used:
            item.last_used_date ??
            item.last_used ??
            null,
          total_months:
            item.total_months,
        }];
      });

  /*
   * Some structured responses expose only the primary
   * skill through `skill`. Add it if the matched_skills
   * array did not already contain it.
   */
  if (
    raw.skill &&
    !matchedSkills.some(
      (item) =>
        item.skill.toLowerCase() ===
        raw.skill!.toLowerCase()
    )
  ) {
    matchedSkills.push({
      skill: raw.skill,
      last_used:
        raw.last_used_date ??
        raw.last_used ??
        null,
      total_months:
        raw.total_months ??
        undefined,
    });
  }

  const evidence: Evidence[] =
    Array.isArray(raw.evidence)
      ? raw.evidence.filter(
          (item) =>
            item &&
            typeof item === "object"
        )
      : [];

  const experienceTimeline: ExperienceTimelineEntry[] =
    Array.isArray(raw.experience_timeline)
      ? raw.experience_timeline
      : [];

  const matchedRequirements: MatchedRequirement[] =
    Array.isArray(raw.matched_requirements)
      ? raw.matched_requirements
      : [];

  const matchedExperience = getMatchedExperience(
    raw,
    experienceTimeline,
    matchedRequirements
  );

  return {
    id: Number(id),
    name,
    email,
    phone: raw.phone ?? nestedCandidate.phone ?? null,
    score: Number(score),
    headline: raw.headline ?? nestedCandidate.headline ?? null,
    location: raw.location ?? nestedCandidate.location ?? null,
    summary: raw.summary ?? nestedCandidate.summary ?? null,
    total_experience_months:
      raw.total_experience_months ??
      nestedCandidate.total_experience_months,
    experience_timeline: experienceTimeline,
    matched_experience: matchedExperience,
    education: Array.isArray(raw.education) ? raw.education : [],
    profile_skills: Array.isArray(raw.profile_skills) ? raw.profile_skills : matchedSkills.map((item) => item.skill),
    projects: Array.isArray(raw.projects) ? raw.projects : [],
    linkedin_url: raw.linkedin_url ?? null,
    github_url: raw.github_url ?? null,
    portfolio_url: raw.portfolio_url ?? null,
    matched_skills: matchedSkills,
    evidence,
    matched_requirements: matchedRequirements,
    explanation: Array.isArray(raw.explanation)
      ? raw.explanation.filter((item): item is string => typeof item === "string")
      : [],
    match_status:
      raw.match_status,
  };
}

function App() {
  const [query, setQuery] = useState("");
  const [suggestedQuery, setSuggestedQuery] = useState<string | null>(null);
  const [data, setData] =
    useState<SearchResponse | null>(null);
  const [loading, setLoading] =
    useState(false);
  const [apiStatus, setApiStatus] = useState<"checking" | "connected" | "offline">("checking");
  const [searchTime, setSearchTime] =
    useState<number | null>(null);
  const [error, setError] =
    useState<string | null>(null);
  const [selectedProfile, setSelectedProfile] = useState<Candidate | null>(null);
  const [candidateView, setCandidateView] = useState<CandidateView>("results");
  const candidateTabScrollRef = useRef<HTMLDivElement | null>(null);
  const candidateTabScrollPositionsRef = useRef<Partial<Record<CandidateView, number>>>({});
  const [shortlistedCandidates, setShortlistedCandidates] = useState<Candidate[]>([]);
  const [hiddenCandidates, setHiddenCandidates] = useState<Candidate[]>([]);
  const [contacts, setContacts] = useState<ContactRecord<ContactCandidate>[]>([]);
  const [contactsReady, setContactsReady] = useState(false);
  const [contactsStorageError, setContactsStorageError] = useState<string | null>(null);
  const [compareCandidateIds, setCompareCandidateIds] = useState<number[]>([]);
  const [outreachCandidateIds, setOutreachCandidateIds] = useState<number[]>([]);
  const [outreachSubject, setOutreachSubject] = useState("A role that may fit your experience");
  const [outreachMessage, setOutreachMessage] = useState(
    "Hi {{firstName}},\n\nI came across your profile and was impressed by your experience. We’re speaking with candidates for a role related to {{searchQuery}} and I thought it could be a good fit.\n\nWould you be open to a short conversation this week?\n\nBest,\n[Your name]"
  );
  const [profileTab, setProfileTab] = useState<ProfileTab>("overview");
  const [selectedRoleFilters, setSelectedRoleFilters] = useState<string[]>([]);
  const [selectedSkillFilters, setSelectedSkillFilters] = useState<string[]>([]);
  const [selectedSeniorityFilters, setSelectedSeniorityFilters] = useState<SeniorityBand[]>([]);
  const [selectedLocationFilters, setSelectedLocationFilters] = useState<SelectedLocation[]>([]);
  const [selectedCompanyFilters, setSelectedCompanyFilters] = useState<string[]>([]);
  const [selectedDomainFilters, setSelectedDomainFilters] = useState<string[]>([]);
  const [selectedMinExperience, setSelectedMinExperience] = useState<string>("");
  const [selectedMaxExperience, setSelectedMaxExperience] = useState<string>("");
  const [appliedRoleFilters, setAppliedRoleFilters] = useState<string[]>([]);
  const [appliedSkillFilters, setAppliedSkillFilters] = useState<string[]>([]);
  const [appliedSeniorityFilters, setAppliedSeniorityFilters] = useState<SeniorityBand[]>([]);
  const [appliedLocationFilters, setAppliedLocationFilters] = useState<SelectedLocation[]>([]);
  const [appliedCompanyFilters, setAppliedCompanyFilters] = useState<string[]>([]);
  const [appliedDomainFilters, setAppliedDomainFilters] = useState<string[]>([]);
  const [appliedMinExperience, setAppliedMinExperience] = useState<number | null>(null);
  const [appliedMaxExperience, setAppliedMaxExperience] = useState<number | null>(null);
  const restoredRef = useRef(false);
  const pendingFiltersRef = useRef<SavedFilters | null>(null);
  const [filterLoading, setFilterLoading] = useState(false);
  const [filterPanelOpen, setFilterPanelOpen] = useState(false);
  const [roleFilterSearch, setRoleFilterSearch] = useState("");
  const [skillFilterSearch, setSkillFilterSearch] = useState("");
  const [locationFilterSearch, setLocationFilterSearch] = useState("");
  const [locationSuggestions, setLocationSuggestions] = useState<LocationSuggestion[]>([]);
  const [locationSuggestionsLoading, setLocationSuggestionsLoading] = useState(false);
  const [locationAutocompleteError, setLocationAutocompleteError] = useState<string | null>(null);
  const [companyFilterSearch, setCompanyFilterSearch] = useState("");

  function navigateCandidateView(nextView: CandidateView, resetNext = false) {
    const scrollPanel = candidateTabScrollRef.current;
    if (scrollPanel) {
      candidateTabScrollPositionsRef.current[candidateView] = scrollPanel.scrollTop;
    }
    if (resetNext) delete candidateTabScrollPositionsRef.current[nextView];
    setCandidateView(nextView);
  }

  function contactCandidateSnapshot(candidate: ContactCandidate): ContactCandidate {
    return {
      id: candidate.id,
      name: candidate.name,
      email: candidate.email,
      phone: candidate.phone,
      linkedin_url: candidate.linkedin_url,
      headline: candidate.headline,
      location: candidate.location,
    };
  }

  function openProfile(candidate: Candidate) {
    console.info("[GenieHire] Candidate profile opened", {
      candidateId: candidate.id,
      experienceEntries: candidate.experience_timeline.length,
      educationEntries: candidate.education.length,
      skills: candidate.profile_skills.length,
      projects: candidate.projects.length,
    });
    setSelectedProfile(candidate);
    setProfileTab("overview");
  }

  function toggleShortlist(candidate: Candidate) {
    const isShortlisted = shortlistedCandidates.some((item) => item.id === candidate.id);
    setShortlistedCandidates((current) =>
      isShortlisted
        ? current.filter((item) => item.id !== candidate.id)
        : [
            ...current,
            {
              ...candidate,
              shortlistSourceQueries: [
                data?.parsed.original_query?.trim() || query.trim(),
              ].filter(Boolean),
            },
          ]
    );
    if (isShortlisted) {
      setCompareCandidateIds((current) => current.filter((id) => id !== candidate.id));
    }
  }

  function hideCandidate(candidate: Candidate) {
    setHiddenCandidates((current) =>
      current.some((item) => item.id === candidate.id)
        ? current
        : [...current, candidate]
    );
  }

  function continueToOutreach() {
    if (compareCandidates.length < 2) return;
    setOutreachCandidateIds(compareCandidates.map((candidate) => candidate.id));
    const now = new Date().toISOString();
    const nextContacts = [...contacts];
    for (const candidate of compareCandidates) {
      const existingIndex = nextContacts.findIndex((contact) => contact.candidate.id === candidate.id);
      if (existingIndex >= 0) {
        nextContacts[existingIndex] = {
          ...nextContacts[existingIndex],
          candidate: contactCandidateSnapshot(candidate),
        };
      } else {
        nextContacts.push({
          candidate: contactCandidateSnapshot(candidate),
          status: "To contact",
          addedAt: now,
          updatedAt: now,
          contactedAt: null,
          sourceQuery: data?.parsed.original_query?.trim() || query.trim() || null,
        });
      }
    }
    setContacts(nextContacts);
    const saved = saveContacts(nextContacts);
    setContactsStorageError(saved.error);
    navigateCandidateView("outreach");
  }

  function updateContactStatus(candidateId: number, status: ContactStatus) {
    const now = new Date().toISOString();
    const existing = contacts.find((contact) => contact.candidate.id === candidateId);
    const candidate = shortlistedCandidates.find((item) => item.id === candidateId) ??
      data?.results.find((item) => item.id === candidateId) ??
      existing?.candidate;
    if (!candidate) return;
    const nextContact: ContactRecord<ContactCandidate> = existing
      ? {
          ...existing,
          candidate: contactCandidateSnapshot(candidate),
          status,
          updatedAt: now,
          contactedAt: status === "Contacted" ? existing.contactedAt ?? now : existing.contactedAt,
        }
      : {
          candidate: contactCandidateSnapshot(candidate),
          status,
          addedAt: now,
          updatedAt: now,
          contactedAt: status === "Contacted" ? now : null,
          sourceQuery: data?.parsed.original_query?.trim() || query.trim() || null,
        };
    const nextContacts = existing
      ? contacts.map((contact) => contact.candidate.id === candidateId ? nextContact : contact)
      : [...contacts, nextContact];
    setContacts(nextContacts);
    const saved = saveContacts(nextContacts);
    setContactsStorageError(saved.error);
  }

  function removeContact(candidateId: number) {
    const nextContacts = contacts.filter((contact) => contact.candidate.id !== candidateId);
    setContacts(nextContacts);
    const saved = saveContacts(nextContacts);
    setContactsStorageError(saved.error);
  }

  useEffect(() => {
    const loaded = loadContacts<ContactCandidate>();
    if (loaded.value) setContacts(loaded.value);
    setContactsStorageError(loaded.error);
    setContactsReady(loaded.value !== null);
  }, []);

  useEffect(() => {
    if (!contactsReady) return;
    const saved = saveContacts(contacts);
    setContactsStorageError(saved.error);
  }, [contacts, contactsReady]);

  function restoreCandidate(candidateId: number) {
    setHiddenCandidates((current) => current.filter((item) => item.id !== candidateId));
  }

  function toggleCompare(candidateId: number) {
    setCompareCandidateIds((current) =>
      current.includes(candidateId)
        ? current.filter((id) => id !== candidateId)
        : current.length < 4
          ? [...current, candidateId]
          : current
    );
  }

  useEffect(() => {
    if (!selectedProfile) return;
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const closeOnEscape = (event: KeyboardEvent) => {
      if (event.key === "Escape") setSelectedProfile(null);
    };
    window.addEventListener("keydown", closeOnEscape);
    return () => {
      document.body.style.overflow = previousOverflow;
      window.removeEventListener("keydown", closeOnEscape);
    };
  }, [selectedProfile]);

  useEffect(() => {
    if (!filterPanelOpen) return;
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const closeOnEscape = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        setSelectedRoleFilters(appliedRoleFilters);
        setSelectedSkillFilters(appliedSkillFilters);
        setSelectedSeniorityFilters(appliedSeniorityFilters);
        setSelectedLocationFilters(appliedLocationFilters);
        setSelectedCompanyFilters(appliedCompanyFilters);
        setSelectedDomainFilters(appliedDomainFilters);
        setSelectedMinExperience(appliedMinExperience === null ? "" : String(appliedMinExperience));
        setSelectedMaxExperience(appliedMaxExperience === null ? "" : String(appliedMaxExperience));
        setRoleFilterSearch("");
        setSkillFilterSearch("");
        setLocationFilterSearch("");
        setLocationSuggestions([]);
        setCompanyFilterSearch("");
        setFilterPanelOpen(false);
      }
    };
    window.addEventListener("keydown", closeOnEscape);
    return () => {
      document.body.style.overflow = previousOverflow;
      window.removeEventListener("keydown", closeOnEscape);
    };
  }, [filterPanelOpen, appliedRoleFilters, appliedSkillFilters, appliedSeniorityFilters, appliedLocationFilters, appliedCompanyFilters, appliedDomainFilters, appliedMinExperience, appliedMaxExperience]);

  useEffect(() => {
    const controller = new AbortController();
    fetch("http://127.0.0.1:8000/health", { signal: controller.signal })
      .then((response) => setApiStatus(response.ok ? "connected" : "offline"))
      .catch(() => {
        if (!controller.signal.aborted) setApiStatus("offline");
      });
    return () => controller.abort();
  }, []);

  useLayoutEffect(() => {
    const scrollPanel = candidateTabScrollRef.current;
    if (scrollPanel) {
      scrollPanel.scrollTop = candidateTabScrollPositionsRef.current[candidateView] ?? 0;
    }
  }, [candidateView]);

  useEffect(() => {
    const originalQuery = data?.parsed?.original_query;
    if (!originalQuery || pendingFiltersRef.current !== null) return;
    saveSearch({
      query: originalQuery,
      filters: {
        roles: appliedRoleFilters,
        skills: appliedSkillFilters,
        seniority: appliedSeniorityFilters,
        locations: appliedLocationFilters,
        companies: appliedCompanyFilters,
        domains: appliedDomainFilters,
        minExperience: appliedMinExperience,
        maxExperience: appliedMaxExperience,
      },
    });
  }, [
    data,
    appliedRoleFilters,
    appliedSkillFilters,
    appliedSeniorityFilters,
    appliedLocationFilters,
    appliedCompanyFilters,
    appliedDomainFilters,
    appliedMinExperience,
    appliedMaxExperience,
  ]);

  useEffect(() => {
    if (restoredRef.current) return;
    restoredRef.current = true;
    const saved = loadSearch();
    if (!saved) return;
    setQuery(saved.query);
    if (hasAnyFilter(saved.filters)) pendingFiltersRef.current = saved.filters;
    void handleSearch(saved.query, true);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (pendingFiltersRef.current === null) return;
    if (error) {
      pendingFiltersRef.current = null;
      return;
    }
    if (!data?.parsed || loading || filterLoading) return;

    const pending = pendingFiltersRef.current;
    pendingFiltersRef.current = null;
    void handleApplyFilters({
      ...pending,
      seniority: pending.seniority as SeniorityBand[],
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [data, loading, filterLoading, error]);


  useEffect(() => {
    const input = locationFilterSearch.trim();
    const apiKey = (import.meta as any).env?.VITE_GEOAPIFY_API_KEY;
    if (input.length < 2 || !filterPanelOpen) {
      setLocationSuggestions([]);
      setLocationSuggestionsLoading(false);
      setLocationAutocompleteError(null);
      return;
    }
    if (!apiKey) {
      setLocationSuggestions([]);
      setLocationAutocompleteError("Geoapify is not configured. Add VITE_GEOAPIFY_API_KEY to your frontend .env file.");
      return;
    }
    let active = true;
    const timeout = window.setTimeout(async () => {
      try {
        setLocationSuggestionsLoading(true);
        setLocationAutocompleteError(null);
        const params = new URLSearchParams({
          text: input, format: "geojson", limit: "7", lang: "en",
          filter: "countrycode:in", apiKey,
        });
        const response = await fetch(`https://api.geoapify.com/v1/geocode/autocomplete?${params.toString()}`);
        if (!response.ok) throw new Error(`Geoapify request failed (${response.status}).`);
        const payload = await response.json();
        if (!active) return;
        const suggestions: LocationSuggestion[] = (payload.features ?? [])
          .map((feature: any) => {
            const properties = feature.properties ?? {};
            return { text: properties.formatted ?? properties.name ?? "", properties };
          })
          .filter((item: LocationSuggestion) => {
            const p = item.properties;
            const type = String(p.result_type ?? "").toLowerCase();
            const usefulTypes = ["city", "town", "village", "municipality", "state", "country"];
            return Boolean(item.text) && usefulTypes.includes(type) && Boolean(
              p.city || p.town || p.village || p.municipality || p.state || p.country || p.name
            );
          });
        setLocationSuggestions(suggestions);
      } catch (error) {
        if (active) {
          setLocationSuggestions([]);
          setLocationAutocompleteError(error instanceof Error ? error.message : "Unable to load location suggestions.");
        }
      } finally {
        if (active) setLocationSuggestionsLoading(false);
      }
    }, 300);
    return () => { active = false; window.clearTimeout(timeout); };
  }, [locationFilterSearch, filterPanelOpen]);

  function selectGeoapifyLocation(suggestion: LocationSuggestion) {
    const p = suggestion.properties;
    const resultType = String(p.result_type ?? "").toLowerCase();
    const cityValue = p.city || p.town || p.village || p.municipality || null;
    const stateValue = p.state || (resultType === "state" ? p.name : null) || null;
    const countryValue = p.country || (resultType === "country" ? p.name : null) || null;
    const selected: SelectedLocation = {
      place_id: String(p.place_id || `${cityValue ?? ""}|${stateValue ?? ""}|${countryValue ?? ""}`),
      label: String(p.formatted || suggestion.text),
      city: cityValue ? String(cityValue) : null,
      state: stateValue ? String(stateValue) : null,
      country: countryValue ? String(countryValue) : null,
    };
    if (!selected.city && !selected.state && !selected.country) {
      setLocationAutocompleteError("Choose a city, state, or country from the suggestions.");
      return;
    }
    setSelectedLocationFilters((current) => current.some((item) => item.place_id === selected.place_id) ? current : [...current, selected]);
    setLocationFilterSearch("");
    setLocationSuggestions([]);
    setLocationAutocompleteError(null);
  }

  async function handleSearch(searchText = query, skipSpellingCheck = false) {
    if (
      !searchText.trim() ||
      loading
    ) {
      return;
    }

    setData(null);
    navigateCandidateView("results", true);
    setCompareCandidateIds([]);
    setOutreachCandidateIds([]);
    setHiddenCandidates([]);
    setError(null);
    setSuggestedQuery(null);
    setSearchTime(null);
    setSelectedRoleFilters([]);
    setSelectedSkillFilters([]);
    setSelectedSeniorityFilters([]);
    setSelectedLocationFilters([]);
    setSelectedCompanyFilters([]);
    setSelectedDomainFilters([]);
    setSelectedMinExperience("");
    setSelectedMaxExperience("");
    setAppliedRoleFilters([]);
    setAppliedSkillFilters([]);
    setAppliedSeniorityFilters([]);
    setAppliedLocationFilters([]);
    setAppliedCompanyFilters([]);
    setAppliedDomainFilters([]);
    setAppliedMinExperience(null);
    setAppliedMaxExperience(null);
    setFilterPanelOpen(false);
    setRoleFilterSearch("");
    setSkillFilterSearch("");
    setLocationFilterSearch("");
    setLocationSuggestions([]);
    setCompanyFilterSearch("");
    setLoading(true);
    const startTime =
      performance.now();
    const controller = new AbortController();
    // Allow the parser and first-use reranker model to finish on slower
    // machines while keeping a hard stop for genuinely stalled requests.
    const timeoutId = window.setTimeout(() => controller.abort(), 90000);
    console.info("[GenieHire] Search started", {
      queryChars: searchText.trim().length,
    });

    try {
      if (!skipSpellingCheck) {
        const spellingResponse = await fetch(SPELLING_CHECK_URL, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          signal: controller.signal,
          body: JSON.stringify({ query: searchText.trim() }),
        });
        if (!spellingResponse.ok) {
          throw new Error(`Spelling check failed (${spellingResponse.status})`);
        }
        const spellingResult: { suggested_query?: string | null } = await spellingResponse.json();
        const correction = spellingResult.suggested_query?.trim();
        if (correction && correction.toLocaleLowerCase() !== searchText.trim().toLocaleLowerCase()) {
          setSuggestedQuery(correction);
          return;
        }
      }

      setSuggestedQuery(null);
      const res = await fetch(
        API_URL,
        {
          method: "POST",
          headers: {
            "Content-Type":
              "application/json",
          },
          signal: controller.signal,
          body: JSON.stringify({
            query: searchText.trim(),
          }),
        }
      );
      setApiStatus("connected");

      if (!res.ok) {
        throw new Error(
          `Server error (${res.status})`
        );
      }

      const response: BackendSearchResponse =
        await res.json();

      const endTime =
        performance.now();

      setSearchTime(
        Number(
          (
            (endTime - startTime) /
            1000
          ).toFixed(3)
        )
      );
      console.info("[GenieHire] Search response received", {
        searchId: response.search_id,
        route: response.route,
        candidates: Array.isArray(response.results) ? response.results.length : 0,
        durationSeconds: ((endTime - startTime) / 1000).toFixed(3),
      });

      if (
        response.valid === false
      ) {
        setError(
          response.errors?.join(
            ", "
          ) ||
            "Invalid query"
        );

        setData(null);
        return;
      }

      /*
       * Normalize the backend response
       * before rendering.
       *
       * This prevents the UI from crashing
       * when structured results contain:
       *
       * {
       *   candidate: {...},
       *   skill: "...",
       *   total_months: ...
       * }
       *
       * or semantic results contain:
       *
       * {
       *   id: ...,
       *   evidence: [...]
       * }
       */
      const normalizedResults =
        Array.isArray(response.results)
          ? response.results
              .map(
                normalizeCandidate
              )
              .filter(
                (
                  candidate
                ): candidate is Candidate =>
                  candidate !== null && candidate.match_status !== "NO_MATCH"
              )
          : [];

      const currentQuery = response.parsed?.original_query?.trim() || searchText.trim();
      setShortlistedCandidates((current) =>
        current.map((shortlisted) => {
          const updatedCandidate = normalizedResults.find(
            (candidate) => candidate.id === shortlisted.id
          );
          if (!updatedCandidate) return shortlisted;
          return {
            ...updatedCandidate,
            shortlistSourceQueries: [
              ...new Set([
                ...(shortlisted.shortlistSourceQueries ?? []),
                currentQuery,
              ].filter(Boolean)),
            ],
          };
        })
      );
      setContacts((current) =>
        current.map((contact) => {
          const updatedCandidate = normalizedResults.find(
            (candidate) => candidate.id === contact.candidate.id
          );
          return updatedCandidate
            ? { ...contact, candidate: contactCandidateSnapshot(updatedCandidate) }
            : contact;
        })
      );

      setData({
        ...response,
        results:
          normalizedResults,
      });
    } catch (e) {
      const endTime =
        performance.now();
      if (e instanceof TypeError) setApiStatus("offline");

      setSearchTime(
        Number(
          (
            (endTime - startTime) /
            1000
          ).toFixed(3)
        )
      );

      setError(
        e instanceof DOMException && e.name === "AbortError"
          ? "Search is taking longer than expected. Please try again shortly."
          : e instanceof Error
            ? e.message
            : "Something went wrong. Is the backend running?"
      );
      console.warn("[GenieHire] Search failed", {
        durationSeconds: ((endTime - startTime) / 1000).toFixed(3),
        error: e instanceof Error ? e.message : "Unknown error",
      });

      setData(null);
    } finally {
      window.clearTimeout(timeoutId);
      setLoading(false);
    }
  }

  async function handleViewResume(
    candidateId: number
  ) {
    console.info("[GenieHire] Resume request started", { candidateId });
    try {
      const response =
        await fetch(
          `${RESUME_API_URL}/${candidateId}/resume`
        );

      if (!response.ok) {
        throw new Error(
          `Unable to fetch resume (${response.status})`
        );
      }

      const resumeData: {
        candidate_id: number;
        resume_url: string;
      } = await response.json();

      window.open(
        resumeData.resume_url,
        "_blank",
        "noopener,noreferrer"
      );
      console.info("[GenieHire] Resume opened", { candidateId });
    } catch (e) {
      console.error("[GenieHire] Resume request failed", {
        candidateId,
        error: e instanceof Error ? e.message : "Unknown error",
      });
      setError(
        e instanceof Error
          ? e.message
          : "Unable to open resume"
      );
    }
  }

  const requirements =
    data?.parsed
      ?.structured_requirements;
  const semanticCriteriaRaw = data?.parsed.requirements
    ?.filter((item) => item.type?.toUpperCase() === "SEMANTIC" && item.mandatory !== false)
    .map((item) => item.original_text?.trim())
    .filter((item): item is string => Boolean(item))
    ?? data?.parsed.semantic_requirements
    ?? (data?.parsed.semantic_requirement ? [data.parsed.semantic_requirement] : []);
  const semanticCriteria = [...new Map(
    semanticCriteriaRaw.map((item) => [item.trim().toLocaleLowerCase(), item.trim()])
  ).values()];
  const temporalCriteria = data?.parsed.requirements?.filter(
    (item) => item.type?.toUpperCase() === "TEMPORAL" && item.temporal_window_months != null,
  ) ?? [];
  const seniorityPolicy = requirements?.seniority_filter ?? null;
  const queryFilterChips = [
    ...(requirements?.skills ?? []).map((value) => ({ key: `skill:${value}`, label: `Skill: ${value}` })),
    ...[...(requirements?.roles ?? []), ...(requirements?.role ? [requirements.role] : [])].map((value) => ({ key: `role:${value}`, label: `Role: ${value}` })),
    ...(requirements?.companies ?? []).map((value) => ({ key: `company:${value}`, label: `Company: ${value}` })),
    ...(requirements?.domains ?? []).map((value) => ({ key: `domain:${value}`, label: `Domain: ${value.replaceAll("_", " ")}` })),
    ...(requirements?.location ? [{ key: "location", label: `Location: ${requirements.location}` }] : []),
    ...(requirements?.experience_min_years != null || requirements?.experience_max_years != null
      ? [{
          key: "experience",
          label: `Experience: ${requirements.experience_min_years != null && requirements.experience_max_years != null
            ? `${requirements.experience_min_years}–${requirements.experience_max_years} years`
            : requirements.experience_min_years != null
              ? `${requirements.experience_min_years}+ years`
              : `up to ${requirements.experience_max_years} years`}`,
        }]
      : []),
    ...(seniorityPolicy
      ? [{
          key: "seniority",
          label: `${seniorityPolicy.seniority} seniority (${seniorityPolicy.experience_scope === "RELEVANT_ROLE" ? "relevant role" : "overall"} experience)`,
        }]
      : []),
  ].filter((item, index, items) => items.findIndex((candidate) => candidate.key.toLocaleLowerCase() === item.key.toLocaleLowerCase()) === index);
  const queryFilterValues = {
    roles: [...(requirements?.roles ?? []), ...(requirements?.role ? [requirements.role] : [])],
    skills: requirements?.skills ?? [],
    companies: requirements?.companies ?? [],
    domains: requirements?.domains ?? [],
  };
  const queryAlreadyIncludes = (field: keyof typeof queryFilterValues, value: string) => {
    const normalize = (item: string) => item.trim().toLocaleLowerCase().replaceAll("_", " ");
    return queryFilterValues[field].some((item) => normalize(item) === normalize(value));
  };
  const queryAlreadyIncludesLocation = (location: SelectedLocation) => {
    const normalize = (value: string) => value.trim().toLocaleLowerCase().replace(/\s+/g, " ");
    const queryLocation = requirements?.location ? normalize(requirements.location) : "";
    return Boolean(queryLocation && [
      location.city,
      location.state,
      location.country,
      location.label,
    ].some((value) => {
      if (!value) return false;
      const candidate = normalize(value);
      return candidate === queryLocation || candidate.startsWith(`${queryLocation},`) || queryLocation.startsWith(`${candidate},`);
    }));
  };
  const queryAlreadyIncludesLocationText = (value: string) =>
    Boolean(requirements?.location && requirements.location.trim().toLocaleLowerCase() === value.trim().toLocaleLowerCase());
  const queryAlreadyIncludesLocationSuggestion = (suggestion: LocationSuggestion) => {
    const p = suggestion.properties;
    const city = p.city || p.town || p.village || p.municipality || null;
    const state = p.state || null;
    const country = p.country || null;
    return queryAlreadyIncludesLocation({
      place_id: String(p.place_id || ""),
      label: String(p.formatted || suggestion.text),
      city: city ? String(city) : null,
      state: state ? String(state) : null,
      country: country ? String(country) : null,
    });
  };
  const formatSeniorityRange = (minMonths: number, maxMonths: number | null) => {
    const formatYears = (months: number) => {
      const years = months / 12;
      return Number.isInteger(years) ? String(years) : years.toFixed(1).replace(/\.0$/, "");
    };
    return maxMonths == null
      ? `${formatYears(minMonths)}+ years`
      : `${formatYears(minMonths)}–${formatYears(maxMonths)} years`;
  };
  const visibleAssumptions = (data?.parsed.assumptions ?? []).filter((assumption) => {
    const isObsoleteSeniorityWarning = /seniority wording.*not converted to an experience-years filter/i.test(assumption);
    return !(seniorityPolicy && isObsoleteSeniorityWarning);
  });
  const resultCount =
    data?.results.length ?? 0;
  const hiddenCandidateIds = new Set(hiddenCandidates.map((candidate) => candidate.id));
  const visibleResultCandidates = (data?.results ?? []).filter(
    (candidate) => !hiddenCandidateIds.has(candidate.id)
  );
  const activeCandidates =
    candidateView === "shortlist"
      ? shortlistedCandidates
      : candidateView === "hidden"
        ? hiddenCandidates
        : visibleResultCandidates;
  const compareCandidates = shortlistedCandidates.filter((candidate) =>
    compareCandidateIds.includes(candidate.id)
  );
  const outreachCandidates = shortlistedCandidates.filter((candidate) =>
    outreachCandidateIds.includes(candidate.id)
  );
  const DOMAIN_OPTIONS = [
    "TECHNICAL",
    "SALES",
    "MARKETING",
    "HR",
    "FINANCE",
    "OPERATIONS",
    "CUSTOMER_SUCCESS",
    "PRODUCT",
    "GENERAL",
  ];
  const includedDomainCount = new Set([...selectedDomainFilters, ...queryFilterValues.domains]).size;

  const selectedMinExperienceNumber = selectedMinExperience.trim() === "" ? null : Number(selectedMinExperience);
  const selectedMaxExperienceNumber = selectedMaxExperience.trim() === "" ? null : Number(selectedMaxExperience);
  const validMinExperience = selectedMinExperienceNumber !== null && Number.isFinite(selectedMinExperienceNumber) && selectedMinExperienceNumber >= 0
    ? selectedMinExperienceNumber : null;
  const validMaxExperience = selectedMaxExperienceNumber !== null && Number.isFinite(selectedMaxExperienceNumber) && selectedMaxExperienceNumber >= 0
    ? selectedMaxExperienceNumber : null;

  const filtersEqual = (
    left: {
      roles: string[]; skills: string[]; seniority: SeniorityBand[]; locations: SelectedLocation[];
      companies: string[]; domains: string[]; minExperience: number | null; maxExperience: number | null;
    },
    right: {
      roles: string[]; skills: string[]; seniority: SeniorityBand[]; locations: SelectedLocation[];
      companies: string[]; domains: string[]; minExperience: number | null; maxExperience: number | null;
    },
  ) =>
    JSON.stringify(left.roles) === JSON.stringify(right.roles) &&
    JSON.stringify(left.skills) === JSON.stringify(right.skills) &&
    JSON.stringify(left.seniority) === JSON.stringify(right.seniority) &&
    JSON.stringify(left.locations) === JSON.stringify(right.locations) &&
    JSON.stringify(left.companies) === JSON.stringify(right.companies) &&
    JSON.stringify(left.domains) === JSON.stringify(right.domains) &&
    left.minExperience === right.minExperience &&
    left.maxExperience === right.maxExperience;

  const hasPendingFilters = !filtersEqual(
    {
      roles: selectedRoleFilters,
      skills: selectedSkillFilters,
      seniority: selectedSeniorityFilters,
      locations: selectedLocationFilters,
      companies: selectedCompanyFilters,
      domains: selectedDomainFilters,
      minExperience: validMinExperience,
      maxExperience: validMaxExperience,
    },
    {
      roles: appliedRoleFilters,
      skills: appliedSkillFilters,
      seniority: appliedSeniorityFilters,
      locations: appliedLocationFilters,
      companies: appliedCompanyFilters,
      domains: appliedDomainFilters,
      minExperience: appliedMinExperience,
      maxExperience: appliedMaxExperience,
    },
  );

  const hasActiveFilters = Boolean(
    appliedRoleFilters.length ||
    appliedSkillFilters.length ||
    appliedSeniorityFilters.length ||
    appliedLocationFilters.length ||
    appliedCompanyFilters.length ||
    appliedDomainFilters.length ||
    appliedMinExperience !== null ||
    appliedMaxExperience !== null
  );

  const appliedFilterCount =
    appliedRoleFilters.length +
    appliedSkillFilters.length +
    appliedSeniorityFilters.length +
    appliedLocationFilters.length +
    appliedCompanyFilters.length +
    appliedDomainFilters.length +
    (appliedMinExperience !== null ? 1 : 0) +
    (appliedMaxExperience !== null ? 1 : 0);

  function openFilterPanel() {
    setSelectedRoleFilters(appliedRoleFilters);
    setSelectedSkillFilters(appliedSkillFilters);
    setSelectedSeniorityFilters(appliedSeniorityFilters);
    setSelectedLocationFilters(appliedLocationFilters);
    setSelectedCompanyFilters(appliedCompanyFilters);
    setSelectedDomainFilters(appliedDomainFilters);
    setSelectedMinExperience(appliedMinExperience === null ? "" : String(appliedMinExperience));
    setSelectedMaxExperience(appliedMaxExperience === null ? "" : String(appliedMaxExperience));
    setRoleFilterSearch("");
    setSkillFilterSearch("");
    setLocationFilterSearch("");
    setLocationSuggestions([]);
    setCompanyFilterSearch("");
    setFilterPanelOpen(true);
  }

  function closeFilterPanel(discardChanges = true) {
    if (discardChanges) {
      setSelectedRoleFilters(appliedRoleFilters);
      setSelectedSkillFilters(appliedSkillFilters);
      setSelectedSeniorityFilters(appliedSeniorityFilters);
      setSelectedLocationFilters(appliedLocationFilters);
      setSelectedCompanyFilters(appliedCompanyFilters);
      setSelectedDomainFilters(appliedDomainFilters);
      setSelectedMinExperience(appliedMinExperience === null ? "" : String(appliedMinExperience));
      setSelectedMaxExperience(appliedMaxExperience === null ? "" : String(appliedMaxExperience));
    }
    setRoleFilterSearch("");
    setSkillFilterSearch("");
    setLocationFilterSearch("");
    setLocationSuggestions([]);
    setCompanyFilterSearch("");
    setFilterPanelOpen(false);
  }

  async function handleApplyFilters(nextFilters?: {
    roles: string[];
    skills: string[];
    seniority: SeniorityBand[];
    locations: SelectedLocation[];
    companies: string[];
    domains: string[];
    minExperience: number | null;
    maxExperience: number | null;
  }) {
    if (!data?.parsed || filterLoading || loading) return;

    const roles = nextFilters?.roles ?? selectedRoleFilters;
    const skills = nextFilters?.skills ?? selectedSkillFilters;
    const seniority = nextFilters?.seniority ?? selectedSeniorityFilters;
    const locations = nextFilters?.locations ?? selectedLocationFilters;
    const companies = nextFilters?.companies ?? selectedCompanyFilters;
    const domains = nextFilters?.domains ?? selectedDomainFilters;
    // Preserve explicit null values: null means the recruiter removed that filter.
    const minExperience = nextFilters ? nextFilters.minExperience : validMinExperience;
    const maxExperience = nextFilters ? nextFilters.maxExperience : validMaxExperience;

    if (minExperience !== null && maxExperience !== null && minExperience >= maxExperience + 1) {
      setError("Minimum experience must be less than the end of the maximum year.");
      return;
    }

    setFilterLoading(true);
    setError(null);
    const startTime = performance.now();
    const controller = new AbortController();
    const timeoutId = window.setTimeout(() => controller.abort(), 90000);

    try {
      const res = await fetch(FILTER_SEARCH_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        signal: controller.signal,
        body: JSON.stringify({
          search_id: data.search_id,
          filters: {
            roles,
            skills,
            seniority,
            locations,
            companies,
            domains,
            experience_min: minExperience,
            experience_max: maxExperience,
          },
        }),
      });

      if (!res.ok) {
        throw new Error(`Filter search failed (${res.status})`);
      }

      const response: BackendSearchResponse = await res.json();
      const normalizedResults = Array.isArray(response.results)
        ? response.results
            .map(normalizeCandidate)
            .filter(
              (candidate): candidate is Candidate =>
                candidate !== null && candidate.match_status !== "NO_MATCH"
            )
        : [];

      setData({ ...response, results: normalizedResults });
      setSelectedRoleFilters(roles);
      setSelectedSkillFilters(skills);
      setSelectedSeniorityFilters(seniority);
      setSelectedLocationFilters(locations);
      setSelectedCompanyFilters(companies);
      setSelectedDomainFilters(domains);
      setSelectedMinExperience(minExperience === null ? "" : String(minExperience));
      setSelectedMaxExperience(maxExperience === null ? "" : String(maxExperience));
      setAppliedRoleFilters(roles);
      setAppliedSkillFilters(skills);
      setAppliedSeniorityFilters(seniority);
      setAppliedLocationFilters(locations);
      setAppliedCompanyFilters(companies);
      setAppliedDomainFilters(domains);
      setAppliedMinExperience(minExperience);
      setAppliedMaxExperience(maxExperience);
      setSearchTime(Number(((performance.now() - startTime) / 1000).toFixed(3)));
      setApiStatus("connected");
      setFilterPanelOpen(false);
      setRoleFilterSearch("");
      setSkillFilterSearch("");
      setLocationFilterSearch("");
        setLocationSuggestions([]);
      setCompanyFilterSearch("");
    } catch (e) {
      setError(
        e instanceof DOMException && e.name === "AbortError"
          ? "Filter search is taking longer than expected. Please try again shortly."
          : e instanceof Error
            ? e.message
            : "Unable to apply filters."
      );
    } finally {
      window.clearTimeout(timeoutId);
      setFilterLoading(false);
    }
  }

  type AppliedFilterKey =
    | "role"
    | "skill"
    | "location"
    | "company"
    | "domain"
    | "seniority"
    | "minExperience"
    | "maxExperience";

  function removeAppliedFilter(filter: AppliedFilterKey, value?: string) {
    const nextFilters = {
      roles: filter === "role" ? appliedRoleFilters.filter((item) => item !== value) : appliedRoleFilters,
      skills: filter === "skill" ? appliedSkillFilters.filter((item) => item !== value) : appliedSkillFilters,
      seniority: filter === "seniority" ? appliedSeniorityFilters.filter((item) => item !== value) : appliedSeniorityFilters,
      locations: filter === "location" ? appliedLocationFilters.filter((item) => item.place_id !== value) : appliedLocationFilters,
      companies: filter === "company" ? appliedCompanyFilters.filter((item) => item !== value) : appliedCompanyFilters,
      domains: filter === "domain" ? appliedDomainFilters.filter((item) => item !== value) : appliedDomainFilters,
      minExperience: filter === "minExperience" ? null : appliedMinExperience,
      maxExperience: filter === "maxExperience" ? null : appliedMaxExperience,
    };

    void handleApplyFilters(nextFilters);
  }

  function clearAllFilters() {
    void handleApplyFilters({
      roles: [],
      skills: [],
      seniority: [],
      locations: [],
      companies: [],
      domains: [],
      minExperience: null,
      maxExperience: null,
    });
  }

  return (
    <div className={`app-shell${data && !loading ? " has-search-results" : ""}`}>
      <SearchHeader status={apiStatus} />

      <main className="main-content">
        <SearchHero query={query} loading={loading} suggestedQuery={suggestedQuery} onQueryChange={setQuery} onClearSuggestion={() => setSuggestedQuery(null)} onSubmit={() => void handleSearch()} onSearchSuggestion={(value) => { setQuery(value); void handleSearch(value, true); }} onSearchOriginal={() => void handleSearch(query, true)} />

        {error && (
          <div className="alert error-alert">
            <div className="alert-icon">
              !
            </div>

            <div>
              <strong>
                Search failed
              </strong>

              <p>{error}</p>
            </div>
          </div>
        )}

        {loading && (
          <section className="loading-state">
            <div className="loading-spinner" />

            <div>
              <strong>Searching for candidates</strong>

              <p>
                Finding profiles that match your requirements. This may take a moment.
              </p>
            </div>
          </section>
        )}

        {data &&
          !loading && (
            <section className="results-section">
              <div className="results-header">
                <div>
                  <div className="results-title-row">
                    <h2>
                      Search results
                    </h2>

                    <span className="result-count">
                      {resultCount}{" "}
                      {resultCount ===
                      1
                        ? "candidate"
                        : "candidates"}
                    </span>
                  </div>

                  <div className="query-display">
                    “
                    {
                      data.parsed
                        .original_query
                    }
                    ”
                  </div>
                </div>

                <div className="search-meta">
                  {searchTime !==
                    null && (
                    <span>
                      {
                        searchTime
                      }
                      s
                    </span>
                  )}

                  <span className="route-badge">
                    <span className="route-dot" />
                    {data.route}
                  </span>
                </div>
              </div>

              <div className="requirement-bar" aria-label="Interpreted search criteria">
                <span className="criteria-heading">Search criteria</span>
                {requirements?.skills?.map(
                  (skill) => (
                    <span
                      className="requirement-pill"
                      key={skill}
                    >
                      {skill}
                    </span>
                  )
                )}

                {(requirements?.experience_min_years != null || requirements?.experience_max_years != null) && (
                    <span className="requirement-pill">
                      {requirements.experience_min_years != null && requirements.experience_max_years != null
                        ? `${requirements.experience_min_years}–${requirements.experience_max_years} years experience`
                        : requirements.experience_min_years != null
                          ? `${requirements.experience_min_years}+ years experience`
                          : `Up to ${requirements.experience_max_years} years experience`}
                    </span>
                  )}

                {requirements?.relevant_experience_min_years !== null &&
                  requirements?.relevant_experience_min_years !== undefined && (
                    <span className="requirement-pill">
                      {requirements.relevant_experience_min_years}+ years relevant experience
                    </span>
                  )}

                {seniorityPolicy && (
                  <>
                    <span className="requirement-pill">
                      {seniorityPolicy.seniority.replaceAll("_", " ")} seniority
                    </span>
                    <span className="requirement-pill">
                      Preferred: {formatSeniorityRange(
                        seniorityPolicy.preferred_min_months,
                        seniorityPolicy.preferred_max_months
                      )}
                    </span>
                    <span className="requirement-pill">
                      Acceptable: {formatSeniorityRange(
                        seniorityPolicy.acceptable_min_months,
                        seniorityPolicy.acceptable_max_months
                      )}
                    </span>
                    <span className="requirement-pill">
                      Based on {seniorityPolicy.experience_scope === "RELEVANT_ROLE"
                        ? "relevant role experience"
                        : "overall experience"}
                    </span>
                  </>
                )}

                {temporalCriteria.map((item, index) => {
                  const months = item.temporal_window_months!;
                  const inferred = (item.confidence ?? 1) < 0.75;
                  return (
                    <span className="requirement-pill" key={`temporal-${item.id ?? index}`}>
                      Recent activity · {inferred ? "assumed " : "last "}{months} {months === 1 ? "month" : "months"}
                    </span>
                  );
                })}

                {(requirements?.roles ?? (requirements?.role ? [requirements.role] : [])).map((role) => (
                  <span className="requirement-pill" key={`role-${role}`}>{role}</span>
                ))}

                {requirements?.companies?.map((company) => (
                  <span className="requirement-pill" key={`company-${company}`}>{company}</span>
                ))}

                {requirements?.location && (
                  <span className="requirement-pill">
                    {requirements.location}
                  </span>
                )}

                {semanticCriteria.map((semantic) => (
                  <span className="requirement-pill semantic-pill" key={`semantic-${semantic}`}>{semantic}</span>
                ))}
              </div>

              {hasActiveFilters && (
                <div className="requirement-bar" aria-label="Applied filters">
                  <span className="criteria-heading">Filters</span>
                  {appliedRoleFilters.map((role) => (
                    <span className="requirement-pill" key={`filter-role-${role}`}>
                      {role}
                      <button type="button" aria-label={`Remove role filter ${role}`} onClick={() => removeAppliedFilter("role", role)} disabled={filterLoading} style={{ marginLeft: "6px", border: 0, background: "transparent", cursor: filterLoading ? "not-allowed" : "pointer" }}>×</button>
                    </span>
                  ))}
                  {appliedSkillFilters.map((skill) => {
                    const alreadyInBaseQuery = (requirements?.skills ?? []).some((baseSkill) => baseSkill.trim().toLocaleLowerCase() === skill.trim().toLocaleLowerCase());
                    return alreadyInBaseQuery ? null : (
                      <span className="requirement-pill" key={`filter-skill-${skill}`}>
                        {skill}
                        <button type="button" aria-label={`Remove skill filter ${skill}`} onClick={() => removeAppliedFilter("skill", skill)} disabled={filterLoading} style={{ marginLeft: "6px", border: 0, background: "transparent", cursor: filterLoading ? "not-allowed" : "pointer" }}>×</button>
                      </span>
                    );
                  })}
                  {appliedLocationFilters.map((location) => (
                    <span className="requirement-pill" key={`filter-location-${location.place_id}`}>
                      {location.label} · Candidate location
                      <button type="button" aria-label={`Remove location filter ${location.label}`} onClick={() => removeAppliedFilter("location", location.place_id)} disabled={filterLoading} style={{ marginLeft: "6px", border: 0, background: "transparent", cursor: filterLoading ? "not-allowed" : "pointer" }}>×</button>
                    </span>
                  ))}
                  {appliedCompanyFilters.map((company) => (
                    <span className="requirement-pill" key={`filter-company-${company}`}>
                      {company}
                      <button type="button" aria-label={`Remove company filter ${company}`} onClick={() => removeAppliedFilter("company", company)} disabled={filterLoading} style={{ marginLeft: "6px", border: 0, background: "transparent", cursor: filterLoading ? "not-allowed" : "pointer" }}>×</button>
                    </span>
                  ))}
                  {appliedDomainFilters.map((domain) => (
                    <span className="requirement-pill" key={`filter-domain-${domain}`}>
                      {domain.replaceAll("_", " ").replace(/\b\w/g, (char) => char.toUpperCase())}
                      <button type="button" aria-label={`Remove domain filter ${domain}`} onClick={() => removeAppliedFilter("domain", domain)} disabled={filterLoading} style={{ marginLeft: "6px", border: 0, background: "transparent", cursor: filterLoading ? "not-allowed" : "pointer" }}>×</button>
                    </span>
                  ))}
                  {appliedMinExperience !== null && (
                    <span className="requirement-pill">
                      {appliedMinExperience}+ years experience
                      <button type="button" aria-label="Remove minimum experience filter" onClick={() => removeAppliedFilter("minExperience")} disabled={filterLoading} style={{ marginLeft: "6px", border: 0, background: "transparent", cursor: filterLoading ? "not-allowed" : "pointer" }}>×</button>
                    </span>
                  )}
                  {appliedMaxExperience !== null && (
                    <span className="requirement-pill">
                      Up to {appliedMaxExperience} years experience
                      <button type="button" aria-label="Remove maximum experience filter" onClick={() => removeAppliedFilter("maxExperience")} disabled={filterLoading} style={{ marginLeft: "6px", border: 0, background: "transparent", cursor: filterLoading ? "not-allowed" : "pointer" }}>×</button>
                    </span>
                  )}
                  {appliedSeniorityFilters.map((band) => (
                    <span className="requirement-pill" key={`filter-seniority-${band}`}>
                      {BANDS.find((item) => item.key === band)?.label ?? band}
                      <button type="button" aria-label={`Remove seniority filter ${band}`} onClick={() => removeAppliedFilter("seniority", band)} disabled={filterLoading} style={{ marginLeft: "6px", border: 0, background: "transparent", cursor: filterLoading ? "not-allowed" : "pointer" }}>×</button>
                    </span>
                  ))}
                  <button type="button" onClick={clearAllFilters} disabled={filterLoading} style={{ border: 0, background: "transparent", color: "#6d28d9", fontSize: "12px", fontWeight: 700, cursor: filterLoading ? "not-allowed" : "pointer", padding: "4px 6px" }}>
                    {filterLoading ? "Updating…" : "Clear all"}
                  </button>
                </div>
              )}

              {visibleAssumptions.length > 0 && (
                <div className="assumption-info">
                  <strong>Search assumptions</strong>
                  {visibleAssumptions.map((assumption) => (
                    <span key={assumption}>{assumption}</span>
                  ))}
                </div>
              )}

              {data.message && (
                <div className="result-message">
                  <span className="message-icon">
                    ✓
                  </span>

                  <span>
                    {data.message}
                  </span>
                </div>
              )}

              {data.route ===
                "HYBRID" && (
                <div className="hybrid-info">
                  <span className="hybrid-icon">
                    ✦
                  </span>

                  <span>
                    Structured requirements
                    and semantic relevance
                    were both used for
                    this search.
                  </span>
                </div>
              )}

              <>
                  <div
                    style={{
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "space-between",
                      gap: "16px",
                      marginBottom: "16px",
                    }}
                  >
                    <div style={{ display: "flex", alignItems: "center", gap: "10px", flexWrap: "wrap" }}>
                      <strong style={{ fontSize: "15px", color: "#202333" }}>
                        Matches ({resultCount})
                      </strong>
                      {hasActiveFilters && (
                        <span style={{ fontSize: "12px", color: "#777b8e" }}>
                          {appliedFilterCount} filter{appliedFilterCount === 1 ? "" : "s"} applied
                        </span>
                      )}
                    </div>

                    <button
                      type="button"
                      onClick={openFilterPanel}
                      disabled={filterLoading || loading}
                      aria-haspopup="dialog"
                      aria-expanded={filterPanelOpen}
                      style={{
                        display: "inline-flex",
                        alignItems: "center",
                        gap: "8px",
                        border: "1px solid #d8d9e4",
                        borderRadius: "10px",
                        background: "#ffffff",
                        color: "#242638",
                        padding: "9px 14px",
                        fontSize: "13px",
                        fontWeight: 700,
                        cursor: "pointer",
                        boxShadow: "0 1px 2px rgba(24, 27, 45, 0.05)",
                      }}
                    >
                      <svg width="16" height="16" viewBox="0 0 24 24" aria-hidden="true">
                        <path d="M4 6h16M7 12h10M10 18h4" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
                      </svg>
                      <span>Filters</span>
                      {appliedFilterCount > 0 && (
                        <span
                          style={{
                            minWidth: "20px",
                            height: "20px",
                            padding: "0 6px",
                            borderRadius: "999px",
                            display: "inline-flex",
                            alignItems: "center",
                            justifyContent: "center",
                            background: "#efe8ff",
                            color: "#6d28d9",
                            fontSize: "11px",
                            fontWeight: 800,
                          }}
                        >
                          {appliedFilterCount}
                        </span>
                      )}
                    </button>
                  </div>

                  {filterPanelOpen && (
                    <div
                      role="presentation"
                      onMouseDown={(event) => {
                        if (event.target === event.currentTarget) closeFilterPanel(true);
                      }}
                      style={{
                        position: "fixed",
                        inset: 0,
                        zIndex: 1000,
                        background: "rgba(20, 22, 35, 0.30)",
                        backdropFilter: "blur(2px)",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        padding: "24px",
                        boxSizing: "border-box",
                      }}
                    >
                      <aside
                        role="dialog"
                        aria-modal="true"
                        aria-labelledby="filter-panel-title"
                        onMouseDown={(event) => event.stopPropagation()}
                        className="result-filter-panel"
                        style={{
                          width: "min(520px, 94vw)",
                          maxHeight: "min(720px, 88vh)",
                          background: "#ffffff",
                          border: "1px solid #e1e2ec",
                          borderRadius: "18px",
                          boxShadow: "0 24px 70px rgba(20, 22, 35, 0.22)",
                          overflow: "hidden",
                          display: "flex",
                          flexDirection: "column",
                          boxSizing: "border-box",
                        }}
                      >
                        <div
                          style={{
                            display: "flex",
                            alignItems: "flex-start",
                            justifyContent: "space-between",
                            gap: "16px",
                            padding: "22px 24px 18px",
                            borderBottom: "1px solid #ececf2",
                            background: "#ffffff",
                            flexShrink: 0,
                          }}
                        >
                          <div>
                            <h2 id="filter-panel-title" style={{ margin: 0, fontSize: "20px", fontWeight: 800, color: "#202333" }}>
                              Filters
                            </h2>
                            <p style={{ margin: "6px 0 0", fontSize: "12px", lineHeight: 1.5, color: "#777b8e" }}>
                              Criteria from your original query are already active. Add filters below to narrow the results further.
                            </p>
                          </div>
                          <button
                            type="button"
                            aria-label="Close filters"
                            onClick={() => closeFilterPanel(true)}
                            style={{
                              width: "36px",
                              height: "36px",
                              flexShrink: 0,
                              border: "1px solid #e1e2ec",
                              borderRadius: "10px",
                              background: "#f7f7fa",
                              color: "#4d5061",
                              fontSize: "21px",
                              lineHeight: 1,
                              cursor: "pointer",
                            }}
                          >
                            ×
                          </button>
                        </div>

                        <div
                          style={{
                            padding: "22px 24px 8px",
                            overflowY: "auto",
                            flex: 1,
                            minHeight: 0,
                          }}
                        >
                          <div style={{ display: "flex", flexDirection: "column", gap: "24px" }}>
                            {queryFilterChips.length > 0 && (
                              <section
                                aria-label="Filters already included from your query"
                                style={{
                                  padding: "13px 14px",
                                  border: "1px solid #e5e2fb",
                                  borderRadius: "11px",
                                  background: "#f8f7ff",
                                }}
                              >
                                <div style={{ color: "#34304f", fontSize: "12px", fontWeight: 750 }}>
                                  Already included from your query
                                </div>
                                <p style={{ margin: "4px 0 10px", color: "#77748e", fontSize: "11px", lineHeight: 1.45 }}>
                                  These criteria are already applied and won’t be added again. Edit the search query to change them.
                                </p>
                                <div style={{ display: "flex", flexWrap: "wrap", gap: "6px" }}>
                                  {queryFilterChips.map((item) => (
                                    <span
                                      key={item.key}
                                      style={{
                                        padding: "5px 8px",
                                        border: "1px solid #e2def8",
                                        borderRadius: "7px",
                                        background: "#fff",
                                        color: "#554d85",
                                        fontSize: "11px",
                                        fontWeight: 600,
                                      }}
                                    >
                                      {item.label}
                                    </span>
                                  ))}
                                </div>
                              </section>
                            )}
                            <fieldset className="filter-group">
                              <legend style={{ fontWeight: 700, color: "#202333" }}>Role</legend>
                              <div className="manual-role-filter">
                                <input
                                  className="filter-dropdown-search"
                                  type="text"
                                  value={roleFilterSearch}
                                  onChange={(event) => setRoleFilterSearch(event.target.value)}
                                  onKeyDown={(event) => {
                                    if (event.key === "Enter") {
                                      event.preventDefault();
                                      const role = roleFilterSearch.trim();
                                      if (role && !queryAlreadyIncludes("roles", role) && !selectedRoleFilters.some((item) => item.toLocaleLowerCase() === role.toLocaleLowerCase())) {
                                        setSelectedRoleFilters((current) => [...current, role]);
                                        setRoleFilterSearch("");
                                      }
                                    }
                                    if (event.key === "Backspace" && !roleFilterSearch.trim() && selectedRoleFilters.length > 0) {
                                      setSelectedRoleFilters((current) => current.slice(0, -1));
                                    }
                                  }}
                                  placeholder="Type a role and press Enter"
                                  aria-label="Add a role filter"
                                />
                                {queryAlreadyIncludes("roles", roleFilterSearch) && (
                                  <p className="filter-group-note">Already included in the original query.</p>
                                )}
                                {selectedRoleFilters.length > 0 && (
                                  <div style={{ display: "flex", flexWrap: "wrap", gap: "7px", marginTop: "8px" }}>
                                    {selectedRoleFilters.map((role) => (
                                      <span key={role} style={{ display: "inline-flex", alignItems: "center", gap: "7px", minHeight: "28px", padding: "4px 7px 4px 10px", border: "1px solid #d9dbe7", borderRadius: "8px", background: "#f7f7fb", color: "#4b4e60", fontSize: "12px", fontWeight: 600, lineHeight: 1 }}>
                                        <span>{role}</span>
                                        <button type="button" aria-label={`Remove ${role}`} onClick={() => setSelectedRoleFilters((current) => current.filter((item) => item !== role))} style={{ width: "18px", height: "18px", padding: 0, border: 0, background: "transparent", color: "#5f6272", cursor: "pointer", fontSize: "15px" }}>×</button>
                                      </span>
                                    ))}
                                  </div>
                                )}
                              </div>
                            </fieldset>

                            <fieldset className="filter-group">
                              <legend style={{ fontWeight: 700, color: "#202333" }}>Skills</legend>
                              <div className="manual-skill-filter">
                                <input
                                  className="filter-dropdown-search"
                                  type="text"
                                  value={skillFilterSearch}
                                  onChange={(event) => setSkillFilterSearch(event.target.value)}
                                  onKeyDown={(event) => {
                                    if (event.key === "Enter") {
                                      event.preventDefault();
                                      const skill = skillFilterSearch.trim();
                                      if (skill && !queryAlreadyIncludes("skills", skill) && !selectedSkillFilters.some((item) => item.toLocaleLowerCase() === skill.toLocaleLowerCase())) {
                                        setSelectedSkillFilters((current) => [...current, skill]);
                                        setSkillFilterSearch("");
                                      }
                                    }
                                    if (event.key === "Backspace" && !skillFilterSearch.trim() && selectedSkillFilters.length > 0) {
                                      setSelectedSkillFilters((current) => current.slice(0, -1));
                                    }
                                  }}
                                  placeholder="Type a skill and press Enter"
                                  aria-label="Add a skill filter"
                                />
                                {queryAlreadyIncludes("skills", skillFilterSearch) && (
                                  <p className="filter-group-note">Already included in the original query.</p>
                                )}
                                {selectedSkillFilters.length > 0 && (
                                  <div style={{ display: "flex", flexWrap: "wrap", gap: "7px", marginTop: "8px" }}>
                                    {selectedSkillFilters.map((skill) => (
                                      <span key={skill} style={{ display: "inline-flex", alignItems: "center", gap: "7px", minHeight: "28px", padding: "4px 7px 4px 10px", border: "1px solid #d9dbe7", borderRadius: "8px", background: "#f7f7fb", color: "#4b4e60", fontSize: "12px", fontWeight: 600, lineHeight: 1 }}>
                                        <span>{skill}</span>
                                        <button type="button" aria-label={`Remove ${skill}`} onClick={() => setSelectedSkillFilters((current) => current.filter((item) => item !== skill))} style={{ width: "18px", height: "18px", padding: 0, border: 0, background: "transparent", color: "#5f6272", cursor: "pointer", fontSize: "15px" }}>×</button>
                                      </span>
                                    ))}
                                  </div>
                                )}
                              </div>
                            </fieldset>

                            <fieldset className="filter-group">
                              <legend style={{ fontWeight: 700, color: "#202333" }}>Location</legend>
                              <div style={{ position: "relative" }}>
                                <input
                                  className="filter-dropdown-search"
                                  type="text"
                                  value={locationFilterSearch}
                                  onChange={(event) => setLocationFilterSearch(event.target.value)}
                                  onKeyDown={(event) => {
                                    if (event.key === "Enter" && locationSuggestions.length > 0) {
                                      event.preventDefault();
                                      if (queryAlreadyIncludesLocationSuggestion(locationSuggestions[0])) {
                                        setLocationFilterSearch("");
                                        setLocationSuggestions([]);
                                      } else {
                                        selectGeoapifyLocation(locationSuggestions[0]);
                                      }
                                    }
                                    if (event.key === "Escape") setLocationSuggestions([]);
                                    if (event.key === "Backspace" && !locationFilterSearch.trim() && selectedLocationFilters.length > 0) {
                                      setSelectedLocationFilters((current) => current.slice(0, -1));
                                    }
                                  }}
                                  placeholder="Search city or locality"
                                  aria-label="Search for a candidate location"
                                  autoComplete="off"
                                />
                                {queryAlreadyIncludesLocationText(locationFilterSearch) && (
                                  <p className="filter-group-note">Already included in the original query.</p>
                                )}
                                {(locationSuggestionsLoading || locationSuggestions.length > 0 || locationAutocompleteError) && (
                                  <div
                                    role="listbox"
                                    style={{
                                      position: "absolute",
                                      zIndex: 30,
                                      top: "calc(100% + 5px)",
                                      left: 0,
                                      right: 0,
                                      background: "#fff",
                                      border: "1px solid #d9dce8",
                                      borderRadius: "9px",
                                      boxShadow: "0 8px 24px rgba(20, 25, 45, 0.12)",
                                      maxHeight: "220px",
                                      overflowY: "auto",
                                    }}
                                  >
                                    {locationSuggestionsLoading && (
                                      <div style={{ padding: "11px 13px", color: "#73788b", fontSize: "13px" }}>Searching locations…</div>
                                    )}
                                    {locationAutocompleteError && (
                                      <div style={{ padding: "11px 13px", color: "#b42318", fontSize: "12px" }}>{locationAutocompleteError}</div>
                                    )}
                                    {locationSuggestions.map((suggestion, index) => (
                                      <button
                                        type="button"
                                        role="option"
                                        aria-selected="false"
                                        key={`${suggestion.properties?.place_id ?? suggestion.text}-${index}`}
                                        onMouseDown={(event) => event.preventDefault()}
                                        onClick={() => {
                                          if (queryAlreadyIncludesLocationSuggestion(suggestion)) {
                                            setLocationFilterSearch("");
                                            setLocationSuggestions([]);
                                          } else {
                                            selectGeoapifyLocation(suggestion);
                                          }
                                        }}
                                        style={{
                                          display: "block",
                                          width: "100%",
                                          padding: "11px 13px",
                                          border: 0,
                                          borderBottom: "1px solid #f0f1f5",
                                          background: "#fff",
                                          color: "#25283a",
                                          textAlign: "left",
                                          cursor: "pointer",
                                          fontSize: "13px",
                                        }}
                                      >
                                        <span style={{ display: "flex", alignItems: "center", gap: "9px" }}>
                                          <span aria-hidden="true">⌖</span>
                                          <span>{suggestion.text}</span>
                                        </span>
                                      </button>
                                    ))}
                                  </div>
                                )}
                              </div>
                             
                              {selectedLocationFilters.length > 0 && (
                                <div style={{ display: "flex", flexWrap: "wrap", gap: "7px", marginTop: "8px" }}>
                                  {selectedLocationFilters.map((location) => (
                                    <span className="requirement-pill" key={location.place_id}>
                                      {location.label}
                                      <button type="button" aria-label={`Remove ${location.label}`} onClick={() => setSelectedLocationFilters((current) => current.filter((item) => item.place_id !== location.place_id))} style={{ marginLeft: "6px", border: 0, background: "transparent", cursor: "pointer" }}>×</button>
                                    </span>
                                  ))}
                                </div>
                              )}
                            </fieldset>

                            <fieldset className="filter-group">
                              <legend style={{ fontWeight: 700, color: "#202333" }}>Experience</legend>
                              <p className="filter-group-note">Filter by total professional experience. The maximum includes that full year (7 means under 8 years).</p>
                              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "10px" }}>
                                <input className="filter-dropdown-search" type="number" min="0" step="0.5" value={selectedMinExperience} disabled={selectedSeniorityFilters.length > 0 && !rangeFromSelection(selectedSeniorityFilters)} onChange={(event) => {
                                  const value = event.target.value;
                                  setSelectedMinExperience(value);
                                  const minimum = value.trim() ? Number(value) : null;
                                  const maximum = selectedMaxExperience.trim() ? Number(selectedMaxExperience) : null;
                                  setSelectedSeniorityFilters(selectionFromRange(minimum, maximum));
                                }} placeholder="Min years" aria-label="Minimum experience in years" />
                                <input className="filter-dropdown-search" type="number" min="0" step="0.5" value={selectedMaxExperience} disabled={selectedSeniorityFilters.length > 0 && !rangeFromSelection(selectedSeniorityFilters)} onChange={(event) => {
                                  const value = event.target.value;
                                  setSelectedMaxExperience(value);
                                  const minimum = selectedMinExperience.trim() ? Number(selectedMinExperience) : null;
                                  const maximum = value.trim() ? Number(value) : null;
                                  setSelectedSeniorityFilters(selectionFromRange(minimum, maximum));
                                }} placeholder="Max years" aria-label="Maximum experience in years" />
                              </div>
                            </fieldset>

                            <fieldset className="filter-group">
                              <legend style={{ fontWeight: 700, color: "#202333" }}>Seniority</legend>
                              <p className="filter-group-note">Based on total experience</p>
                              {BANDS.map((band) => (
                                <label className="filter-option" key={band.key}>
                                  <input
                                    type="checkbox"
                                    checked={selectedSeniorityFilters.includes(band.key)}
                                    onChange={() => {
                                      const next = selectedSeniorityFilters.includes(band.key)
                                        ? selectedSeniorityFilters.filter((item) => item !== band.key)
                                        : [...selectedSeniorityFilters, band.key];
                                      setSelectedSeniorityFilters(next);
                                      if (next.length === 0) {
                                        setSelectedMinExperience("");
                                        setSelectedMaxExperience("");
                                        return;
                                      }
                                      const range = rangeFromSelection(next);
                                      setSelectedMinExperience(range ? String(range.min) : "");
                                      setSelectedMaxExperience(range?.max == null ? "" : String(range.max));
                                    }}
                                  />
                                  <span>{band.label}{band.max === null ? ` · ${band.min}+ years` : ` · ${band.min}–${band.max} years`}</span>
                                </label>
                              ))}
                            </fieldset>

                            <fieldset className="filter-group">
                              <legend style={{ fontWeight: 700, color: "#202333" }}>Company</legend>
                              <div className="company-filter-input">
                                <input
                                  className="filter-dropdown-search"
                                  type="text"
                                  value={companyFilterSearch}
                                  onChange={(event) => setCompanyFilterSearch(event.target.value)}
                                  onKeyDown={(event) => {
                                    if (event.key === "Enter") {
                                      event.preventDefault();
                                      const company = companyFilterSearch.trim();
                                      if (company && !queryAlreadyIncludes("companies", company) && !selectedCompanyFilters.some((item) => item.toLocaleLowerCase() === company.toLocaleLowerCase())) {
                                        setSelectedCompanyFilters((current) => [...current, company]);
                                        setCompanyFilterSearch("");
                                      }
                                    }
                                    if (event.key === "Backspace" && !companyFilterSearch.trim() && selectedCompanyFilters.length > 0) {
                                      setSelectedCompanyFilters((current) => current.slice(0, -1));
                                    }
                                  }}
                                  placeholder="Type a company"
                                  aria-label="Add a company filter"
                                />
                                <button
                                  type="button"
                                  className="company-filter-add"
                                  disabled={!companyFilterSearch.trim() || queryAlreadyIncludes("companies", companyFilterSearch)}
                                  onClick={() => {
                                    const company = companyFilterSearch.trim();
                                    if (company && !queryAlreadyIncludes("companies", company) && !selectedCompanyFilters.some((item) => item.toLocaleLowerCase() === company.toLocaleLowerCase())) {
                                      setSelectedCompanyFilters((current) => [...current, company]);
                                    }
                                    setCompanyFilterSearch("");
                                  }}
                                >
                                  Add
                                </button>
                              </div>
                              {queryAlreadyIncludes("companies", companyFilterSearch) && (
                                <p className="filter-group-note">Already included in the original query.</p>
                              )}
                              {selectedCompanyFilters.length > 0 && (
                                <div style={{ display: "flex", flexWrap: "wrap", gap: "7px", marginTop: "8px" }}>
                                  {selectedCompanyFilters.map((company) => (
                                    <span className="requirement-pill" key={company}>
                                      {company}
                                      <button type="button" aria-label={`Remove ${company}`} onClick={() => setSelectedCompanyFilters((current) => current.filter((item) => item !== company))} style={{ marginLeft: "6px", border: 0, background: "transparent", cursor: "pointer" }}>×</button>
                                    </span>
                                  ))}
                                </div>
                              )}
                            </fieldset>

                            <fieldset className="filter-group">
                              <legend style={{ fontWeight: 700, color: "#202333" }}>Domain</legend>
                              <details className="filter-dropdown filter-domain-dropdown">
                                <summary className="filter-dropdown-trigger">
                                  <span>
                                    {includedDomainCount
                                      ? `${includedDomainCount} domain${includedDomainCount === 1 ? "" : "s"} included`
                                      : "Select domains"}
                                  </span>
                                  <span className="filter-dropdown-chevron" aria-hidden="true">⌄</span>
                                </summary>
                                <div className="filter-dropdown-menu filter-domain-options">
                                  {DOMAIN_OPTIONS.map((domain) => (
                                    <label className="filter-option" key={domain}>
                                      <input type="checkbox" checked={selectedDomainFilters.includes(domain) || queryAlreadyIncludes("domains", domain)} disabled={queryAlreadyIncludes("domains", domain)} onChange={() => setSelectedDomainFilters((current) => current.includes(domain) ? current.filter((item) => item !== domain) : [...current, domain])} />
                                      <span>{domain.replaceAll("_", " ").replace(/\b\w/g, (char) => char.toUpperCase())}</span>
                                      {queryAlreadyIncludes("domains", domain) && <span className="filter-group-note">From query</span>}
                                    </label>
                                  ))}
                                </div>
                              </details>
                            </fieldset>
                          </div>
                        </div>

                        <div
                          style={{
                            padding: "14px 24px 18px",
                            background: "#ffffff",
                            borderTop: "1px solid #ececf2",
                            display: "flex",
                            alignItems: "center",
                            justifyContent: "space-between",
                            gap: "12px",
                            flexShrink: 0,
                          }}
                        >
                          <button
                            type="button"
                            onClick={clearAllFilters}
                            disabled={(!hasActiveFilters && !hasPendingFilters) || filterLoading}
                            style={{
                              border: 0,
                              background: "transparent",
                              color: "#6d28d9",
                              fontSize: "13px",
                              fontWeight: 700,
                              cursor: "pointer",
                              padding: "10px 2px",
                              opacity: (!hasActiveFilters && !hasPendingFilters) || filterLoading ? 0.45 : 1,
                            }}
                          >
                            Clear all
                          </button>

                          <div style={{ display: "flex", gap: "8px" }}>
                            <button
                              type="button"
                              onClick={() => closeFilterPanel(true)}
                              disabled={filterLoading}
                              style={{
                                border: "1px solid #d8d9e4",
                                borderRadius: "9px",
                                background: "#fff",
                                color: "#36394a",
                                padding: "10px 15px",
                                fontSize: "13px",
                                fontWeight: 700,
                                cursor: "pointer",
                              }}
                            >
                              Cancel
                            </button>

                            <button
                              type="button"
                              className="filter-apply-button"
                              disabled={!hasPendingFilters || filterLoading}
                              onClick={() => void handleApplyFilters()}
                              style={{
                                border: "1px solid #171a2b",
                                borderRadius: "9px",
                                background: !hasPendingFilters || filterLoading ? "#e9e9ee" : "#171a2b",
                                color: !hasPendingFilters || filterLoading ? "#9295a4" : "#ffffff",
                                padding: "10px 16px",
                                fontSize: "13px",
                                fontWeight: 800,
                                cursor: !hasPendingFilters || filterLoading ? "not-allowed" : "pointer",
                                boxShadow: !hasPendingFilters || filterLoading ? "none" : "0 4px 12px rgba(23, 26, 43, 0.12)",
                              }}
                            >
                              {filterLoading ? "Applying…" : "Apply filters"}
                            </button>
                          </div>
                        </div>
                      </aside>
                    </div>
                  )}

                  <div className="results-list-column">
                    <div className="candidate-view-toolbar">
                      <div className="candidate-view-tabs" aria-label="Candidate lists">
                        <button
                          type="button"
                          className={candidateView === "results" ? "active" : ""}
                          aria-pressed={candidateView === "results"}
                          onClick={() => navigateCandidateView("results")}
                        >
                          Results <span>{visibleResultCandidates.length}</span>
                        </button>
                        <button
                          type="button"
                          className={candidateView === "shortlist" || candidateView === "compare" || candidateView === "outreach" ? "active" : ""}
                          aria-pressed={candidateView === "shortlist" || candidateView === "compare" || candidateView === "outreach"}
                          onClick={() => navigateCandidateView("shortlist")}
                        >
                          Shortlist <span>{shortlistedCandidates.length}</span>
                        </button>
                        <button
                          type="button"
                          className={candidateView === "contacts" ? "active" : ""}
                          aria-pressed={candidateView === "contacts"}
                          onClick={() => navigateCandidateView("contacts")}
                        >
                          Contacts <span>{contacts.length}</span>
                        </button>
                        <button
                          type="button"
                          className={candidateView === "hidden" ? "active" : ""}
                          aria-pressed={candidateView === "hidden"}
                          onClick={() => navigateCandidateView("hidden")}
                        >
                          Hidden <span>{hiddenCandidates.length}</span>
                        </button>
                      </div>
                      {candidateView === "shortlist" && (
                        <div className="shortlist-controls">
                          <span>{compareCandidateIds.length} selected · choose 2–4 to compare</span>
                          <button
                            type="button"
                            className="candidate-action-button candidate-action-primary"
                            disabled={compareCandidates.length < 2}
                            onClick={() => navigateCandidateView("compare")}
                          >
                            Compare{compareCandidateIds.length ? ` (${compareCandidateIds.length})` : ""}
                          </button>
                        </div>
                      )}
                    </div>

                    <div
                      className="candidate-tab-scroll"
                      ref={candidateTabScrollRef}
                      onScroll={(event) => {
                        candidateTabScrollPositionsRef.current[candidateView] = event.currentTarget.scrollTop;
                      }}
                    >
                    {candidateView === "contacts" ? (
                      <section className="contacts-view">
                        <div className="comparison-heading">
                          <div>
                            <span className="workflow-eyebrow">CANDIDATE PIPELINE</span>
                            <h3>Contacts</h3>
                            <p>Track who you plan to contact and what happened next. Opening a draft does not mark it as sent.</p>
                          </div>
                        </div>
                        {contactsStorageError && (
                          <p className="contacts-storage-error" role="alert">{contactsStorageError}</p>
                        )}
                        {contacts.length ? (
                          <div className="contacts-list">
                            {contacts.map((contact) => {
                              const candidate = contact.candidate;
                              return (
                                <article className="contact-row" key={candidate.id}>
                                  <span className="avatar">{getInitials(candidate.name)}</span>
                                  <div className="contact-row-info">
                                    <strong>{candidate.name}</strong>
                                    <span>{candidate.email || candidate.phone || "No email or phone on profile"}</span>
                                    <small>
                                      {contact.sourceQuery ? `From: ${contact.sourceQuery} · ` : ""}
                                      {contact.contactedAt
                                        ? `Contacted ${new Date(contact.contactedAt).toLocaleDateString()}`
                                        : `Added ${new Date(contact.addedAt).toLocaleDateString()}`}
                                    </small>
                                  </div>
                                  <label className="contact-status-control">
                                    <span>Status</span>
                                    <select
                                      value={contact.status}
                                      aria-label={`${candidate.name} contact status`}
                                      onChange={(event) => updateContactStatus(candidate.id, event.target.value as ContactStatus)}
                                    >
                                      {CONTACT_STATUSES.map((status) => <option key={status} value={status}>{status}</option>)}
                                    </select>
                                  </label>
                                  {candidate.email && (
                                    <a
                                      className="candidate-action-button"
                                      href={buildMailtoLink(
                                        candidate.email,
                                        outreachSubject.replaceAll("{{firstName}}", candidate.name.split(/\s+/)[0] ?? candidate.name),
                                        outreachMessage
                                          .replaceAll("{{firstName}}", candidate.name.split(/\s+/)[0] ?? candidate.name)
                                          .replaceAll("{{searchQuery}}", contact.sourceQuery ?? "our open role")
                                      )}
                                    >
                                      Draft email
                                    </a>
                                  )}
                                  {normalizeExternalUrl(candidate.linkedin_url) && (
                                    <a
                                      className="candidate-action-button"
                                      href={normalizeExternalUrl(candidate.linkedin_url) ?? undefined}
                                      target="_blank"
                                      rel="noopener noreferrer"
                                    >
                                      LinkedIn
                                    </a>
                                  )}
                                  {candidate.phone && (
                                    <a className="candidate-action-button" href={`tel:${candidate.phone}`}>
                                      Call
                                    </a>
                                  )}
                                  <button
                                    type="button"
                                    className="outreach-remove-button"
                                    aria-label={`Remove ${candidate.name} from contacts`}
                                    title="Remove from contacts"
                                    onClick={() => removeContact(candidate.id)}
                                  >
                                    ×
                                  </button>
                                </article>
                              );
                            })}
                          </div>
                        ) : (
                          <div className="outreach-empty">
                            No contacts yet. Compare shortlisted candidates and continue to outreach to add finalists here.
                          </div>
                        )}
                        <p className="contacts-storage-note">Contacts are saved in this browser on this device.</p>
                      </section>
                    ) : candidateView === "outreach" ? (
                      <section className="outreach-view">
                        <div className="comparison-heading">
                          <div>
                            <span className="workflow-eyebrow">FINAL STEP</span>
                            <h3>Outreach your finalists</h3>
                            <p>Review the note, then open a separate email draft for each candidate. Nothing is sent without your approval.</p>
                          </div>
                          <button
                            type="button"
                            className="candidate-action-button"
                            onClick={() => navigateCandidateView("compare")}
                          >
                            ← Back to comparison
                          </button>
                        </div>

                        <div className="outreach-layout">
                          <div className="outreach-recipients">
                          {contactsStorageError && (
                            <p className="contacts-storage-error" role="alert">{contactsStorageError}</p>
                          )}
                          <div className="outreach-section-heading">
                              <div>
                                <strong>Selected candidates</strong>
                                <span>{outreachCandidates.length} finalist{outreachCandidates.length === 1 ? "" : "s"}</span>
                              </div>
                              <button
                                type="button"
                                onClick={() => setOutreachCandidateIds(compareCandidates.map((candidate) => candidate.id))}
                                disabled={outreachCandidateIds.length === compareCandidates.length}
                              >
                                Reset selection
                              </button>
                            </div>
                            {outreachCandidates.length ? outreachCandidates.map((candidate) => (
                              <article className="outreach-recipient" key={candidate.id}>
                                <span className="avatar">{getInitials(candidate.name)}</span>
                                <div className="outreach-recipient-info">
                                  <strong>{candidate.name}</strong>
                                  {candidate.email
                                    ? <span>{candidate.email}</span>
                                    : <span className="outreach-no-email">No email on profile</span>}
                                </div>
                                {candidate.email ? (
                                  <a
                                    className="candidate-action-button candidate-action-primary outreach-send-button"
                                    href={buildMailtoLink(
                                      candidate.email,
                                      outreachSubject.replaceAll("{{firstName}}", candidate.name.split(/\s+/)[0] ?? candidate.name),
                                      outreachMessage
                                        .replaceAll("{{firstName}}", candidate.name.split(/\s+/)[0] ?? candidate.name)
                                        .replaceAll("{{searchQuery}}", data?.parsed.original_query ?? "our open role")
                                    )}
                                  >
                                    Open email draft <span aria-hidden="true">↗</span>
                                  </a>
                                ) : normalizeExternalUrl(candidate.linkedin_url) ? (
                                  <a
                                    className="candidate-action-button outreach-link-button"
                                    href={normalizeExternalUrl(candidate.linkedin_url) ?? undefined}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                  >
                                    LinkedIn <span aria-hidden="true">↗</span>
                                  </a>
                                ) : candidate.phone ? (
                                  <a className="candidate-action-button outreach-link-button" href={`tel:${candidate.phone}`}>
                                    Call
                                  </a>
                                ) : (
                                  <span className="outreach-unavailable">No contact link</span>
                                )}
                                <label className="outreach-status-control">
                                  <span className="sr-only">{candidate.name} contact status</span>
                                  <select
                                    aria-label={`${candidate.name} contact status`}
                                    value={contacts.find((contact) => contact.candidate.id === candidate.id)?.status ?? "To contact"}
                                    onChange={(event) => updateContactStatus(candidate.id, event.target.value as ContactStatus)}
                                  >
                                    {CONTACT_STATUSES.map((status) => <option key={status} value={status}>{status}</option>)}
                                  </select>
                                </label>
                                {(contacts.find((contact) => contact.candidate.id === candidate.id)?.status ?? "To contact") === "To contact" && (
                                  <button
                                    type="button"
                                    className="contact-mark-button"
                                    onClick={() => updateContactStatus(candidate.id, "Contacted")}
                                  >
                                    Mark contacted
                                  </button>
                                )}
                                <button
                                  type="button"
                                  className="outreach-remove-button"
                                  aria-label={`Remove ${candidate.name} from outreach`}
                                  onClick={() => setOutreachCandidateIds((current) =>
                                    current.filter((id) => id !== candidate.id)
                                  )}
                                >
                                  ×
                                </button>
                              </article>
                            )) : (
                              <div className="outreach-empty">
                                No candidates selected. Go back to comparison and select your finalists.
                              </div>
                            )}
                          </div>

                          <div className="outreach-composer">
                            <div className="outreach-section-heading">
                              <div>
                                <strong>Email template</strong>
                                <span>Personalized draft, one candidate at a time</span>
                              </div>
                            </div>
                            <label>
                              Subject
                              <input
                                value={outreachSubject}
                                onChange={(event) => setOutreachSubject(event.target.value)}
                                aria-label="Outreach email subject"
                              />
                            </label>
                            <label>
                              Message
                              <textarea
                                value={outreachMessage}
                                onChange={(event) => setOutreachMessage(event.target.value)}
                                aria-label="Outreach email message"
                                rows={11}
                              />
                            </label>
                            <p className="outreach-template-hint">
                              Use <code>{"{{firstName}}"}</code> and <code>{"{{searchQuery}}"}</code> to personalize each draft.
                              {" "}Drafts open in your email app; update a candidate’s status only after taking that action.
                            </p>
                          </div>
                        </div>
                      </section>
                    ) : candidateView === "compare" ? (
                      <section className="comparison-view">
                        <div className="comparison-heading">
                          <div>
                            <h3>Compare shortlisted candidates</h3>
                            <p>Review the essentials side by side.</p>
                          </div>
                          <button
                            type="button"
                            className="candidate-action-button"
                            onClick={() => navigateCandidateView("shortlist")}
                          >
                            Back to shortlist
                          </button>
                        </div>
                        {compareCandidates.length >= 2 ? (
                          <>
                            <div className="comparison-scroll">
                              <table className="comparison-table">
                              <thead>
                                <tr>
                                  <th scope="col">Criteria</th>
                                  {compareCandidates.map((candidate) => (
                                    <th scope="col" key={candidate.id}>
                                      <div className="comparison-candidate">
                                        <span className="avatar">{getInitials(candidate.name)}</span>
                                        <strong>{candidate.name}</strong>
                                        <button type="button" onClick={() => openProfile(candidate)}>
                                          View profile
                                        </button>
                                      </div>
                                    </th>
                                  ))}
                                </tr>
                              </thead>
                              <tbody>
                                <tr>
                                  <th scope="row">Experience</th>
                                  {compareCandidates.map((candidate) => (
                                    <td key={candidate.id}>
                                      {candidate.total_experience_months == null
                                        ? "Not listed"
                                        : formatMonths(candidate.total_experience_months)}
                                    </td>
                                  ))}
                                </tr>
                                <tr>
                                  <th scope="row">Current role</th>
                                  {compareCandidates.map((candidate) => {
                                    const currentRole =
                                      candidate.experience_timeline.find((item) => item.is_current) ??
                                      candidate.experience_timeline[0];
                                    return (
                                      <td key={candidate.id}>
                                        {currentRole?.role ?? candidate.headline ?? "Not listed"}
                                        {currentRole?.company ? ` · ${currentRole.company}` : ""}
                                      </td>
                                    );
                                  })}
                                </tr>
                                <tr>
                                  <th scope="row">Location</th>
                                  {compareCandidates.map((candidate) => (
                                    <td key={candidate.id}>{candidate.location ?? "Not listed"}</td>
                                  ))}
                                </tr>
                                <tr>
                                  <th scope="row">Match</th>
                                  {compareCandidates.map((candidate) => (
                                    <td key={candidate.id}>
                                      {getCandidateDisplayMatchStatus(
                                        candidate.match_status,
                                        candidate.matched_requirements
                                      ) === "MATCH" ? "Match" : "Partial match"}
                                    </td>
                                  ))}
                                </tr>
                                <tr>
                                  <th scope="row">Found in searches</th>
                                  {compareCandidates.map((candidate) => (
                                    <td key={candidate.id}>
                                      {candidate.shortlistSourceQueries?.join(" · ") || "Current search"}
                                    </td>
                                  ))}
                                </tr>
                                <tr>
                                  <th scope="row">Key skills</th>
                                  {compareCandidates.map((candidate) => (
                                    <td key={candidate.id}>
                                      {[...new Set([
                                        ...candidate.profile_skills,
                                        ...candidate.matched_skills.map((item) => item.skill),
                                      ])].slice(0, 6).join(", ") || "Not listed"}
                                    </td>
                                  ))}
                                </tr>
                                <tr>
                                  <th scope="row">Education</th>
                                  {compareCandidates.map((candidate) => {
                                    const education = candidate.education[0];
                                    return (
                                      <td key={candidate.id}>
                                        {education
                                          ? [education.degree, education.field_of_study, education.institution]
                                              .filter(Boolean)
                                              .join(" · ")
                                          : "Not listed"}
                                      </td>
                                    );
                                  })}
                                </tr>
                                <tr>
                                  <th scope="row">Matching evidence</th>
                                  {compareCandidates.map((candidate) => {
                                    const matches = candidate.matched_requirements
                                      .filter((item) => item.matched)
                                      .slice(0, 3)
                                      .map((item) => item.requirement);
                                    return <td key={candidate.id}>{matches.join(", ") || "Review profile"}</td>;
                                  })}
                                </tr>
                              </tbody>
                              </table>
                            </div>
                            <div className="comparison-next-step">
                              <p>
                                Ready to contact your finalists? We’ll prepare an individual email draft for each selected candidate.
                              </p>
                              <button
                                type="button"
                                className="candidate-action-button candidate-action-primary"
                                disabled={compareCandidates.length < 2}
                                onClick={continueToOutreach}
                              >
                                Continue to outreach <span aria-hidden="true">→</span>
                              </button>
                            </div>
                          </>
                        ) : (
                          <div className="filter-empty-state">
                            Select at least two candidates from your shortlist to compare.
                          </div>
                        )}
                      </section>
                    ) : activeCandidates.length ? (
                      <div className="candidate-list">
                  {activeCandidates.map((candidate) => (
                    <CandidateCard
                      key={candidate.id}
                      candidate={candidate}
                      candidateView={candidateView}
                      requirements={requirements}
                      seniorityPolicy={seniorityPolicy}
                      isShortlisted={shortlistedCandidates.some((item) => item.id === candidate.id)}
                      compareSelected={compareCandidateIds.includes(candidate.id)}
                      compareDisabled={!compareCandidateIds.includes(candidate.id) && compareCandidateIds.length >= 4}
                      onToggleCompare={toggleCompare}
                      onHide={hideCandidate}
                      onRestore={restoreCandidate}
                      onToggleShortlist={toggleShortlist}
                      onOpenProfile={openProfile}
                    />
                  ))}
                      </div>
                    ) : (
                      <div className="filter-empty-state">
                        <strong>
                          {candidateView === "shortlist"
                            ? "Your shortlist is empty"
                            : candidateView === "hidden"
                              ? "No hidden candidates"
                              : "No candidates found"}
                        </strong>
                        <p>
                          {candidateView === "shortlist"
                            ? "Shortlist candidates from Results to keep your strongest matches together."
                            : candidateView === "hidden"
                              ? "Candidates you hide will appear here, and you can restore them anytime."
                              : "Try changing the search or adjusting the applied filters."}
                        </p>
                      </div>
                    )}
                    </div>
                  </div>
              </>
            </section>
          )}
      </main>

      <CandidateProfileDialog candidate={selectedProfile} profileTab={profileTab} onProfileTabChange={setProfileTab} onClose={() => setSelectedProfile(null)} onViewResume={(candidateId) => void handleViewResume(candidateId)} />
    </div>
  );
}

export default App;
